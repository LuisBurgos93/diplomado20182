//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)
var edad = 18

switch edad{
case 10:
    print("Muy chico")
case 18:
    print("Exacto")
default:
    print("ya es ma")
}

edad = 5

switch edad{
case 0..<18:
    print("muy chico")
case 18:
    print("Exacto")
default:
    print("ya es mayorcito")
}

var animal = "gato"

switch animal{
case "perro", "gato":
    print("animal domestico")
default:
    print("Ni idea")
}

var coordenadas3D: (x: Int, y: Int, z: Int) = (x: 3, y: 0, z: 20)

switch coordenadas3D{
case(0, 0, 0):
    print ("Origen")
case (_, 0, 0):
    print("En x")
case(0, let y, 0):
    print("en y \(y)")
default:
    break
    
}
