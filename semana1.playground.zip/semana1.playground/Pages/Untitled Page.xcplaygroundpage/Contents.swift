//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)

let nombre = "sddcf"

let apellido:String = "ddss"
//String, Int, Float, Double, Bool,

var promedio: Float = 6.9

var entero = Int(promedio)
//if, else if, else
var a = 10
var b = 20
//condiciones ==,<,>,=>,<=, !=

var condicion: Bool = true
if condicion {
    print("Hola Mundo")
}
else{
    print("Adios Mundo")
}

func funcion(){
    
}

var tupla: (Int, Int) = (3, 5)

print(tupla.0)

var tupla2 = (20,20)

var coordenadas: (x:Int, y:Int) = (x:20, y:20)
coordenadas.x

let(x, y) = coordenadas

var rangos=0...10


var rangos2 = 0..<10
var rangos3 = (0...10).reversed()
var rangos4 = stride(from:10, to: 100, by: 4)

var valor = 0
while valor < 10 {
    print(valor)
    valor += 1
}

repeat{
 print(valor)
valor += 1
}while valor < 10


