//: [Previous](@previous)

import Foundation

var str = "Hello, playground"


var n=0
var i=0
var bool = true
var pre = 3, pos = 5, val = 0, x = 100


func primo(n: Int){
    for i in 2...n-1{
        if n%i == 0{
            bool = true
            break
        }
        else{
            bool = false
        }
    }
    if bool == true{
        print(n)
        print("no es primo")
    }
    else{
        print(n)
        print("es primo")
    }
}

print(primo(n: 67))

while val <= 1000{
    val = pre + pos
    pre = pos
    pos = val
    print(primo(n: val))
}


