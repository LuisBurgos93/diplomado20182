//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)
var cadena = " ccs"

func palindromo(Str: String){
    if String(Str.reversed())==Str {
        print("es palindromo")
    }
    else{
        print("no se palindromo")
    }
}

palindromo(Str: "papu")

func letras(Str: String, Str2: String){
    if String(Str.sorted())==String(Str2.sorted()){
        print("mismas letras")
        }
    else{
        print("diferentes")
    }
}
