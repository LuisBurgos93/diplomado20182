//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

var valor = 10
//: [Next](@next)
for i in  0...10 where i % 2 == 0{
    valor += 1
    print(valor)
}

var n = 6

for _ in 0...6{
    if n == 0 || n == 1{
        n=1
        
    }
    else{
    n=n*(n-1)
    print(n)
    }
}
