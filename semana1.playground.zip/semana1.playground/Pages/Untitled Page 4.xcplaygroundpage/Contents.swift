//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)
func fuction(valor: Int){
    print(valor)
}

fuction(valor:10)
func sinNombrarParametros(_ valor: Int){
    print(valor)
}

sinNombrarParametros(20)

func renombrarParametros(otroNombre valor: Int){
    print(valor)
}

renombrarParametros(otroNombre: 30)

func multiplica(_ x:Int, por y:Int) -> Int{
    return x * y
}

multiplica (5, por: 10)

func divide(_ x:Int, entre y:Int)->(resultado: Int, residuo: Int){
    return (x/y, x%y)
}

let resultados = divide(15, entre: 4)
print (resultados.residuo)
print (resultados.resultado)

func suma(_ a: inout Int){
    a += 1
    print(a)
    
}

var numero = 4
suma(&numero)
print(numero)


func getValue(_ x: Int) -> Int{
    return x
}

func getValue(_ x: String) -> String{
    return x
}

var x = getValue("Cadena")


func paisdelNunca() -> Never{
    
}
